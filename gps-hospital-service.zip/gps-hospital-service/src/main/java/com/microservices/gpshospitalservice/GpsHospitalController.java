package com.microservices.gpshospitalservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin("http://localhost:3000/")
@RestController
public class GpsHospitalController {
	
	@Autowired
	private HospitalRepository repository;
	
	@GetMapping("/emergency")
	public List<HospitalDetailsTemp> retrieveEmergencyHospital() {
			return repository.emergency();
	}
	
	@GetMapping("/beds")
	public List<HospitalDetailsTemp> retrieveBedsHospital() {
		return repository.emergencyBeds();
		
	}
	
	
	@GetMapping("/emergency/{specialist}")
	public List<HospitalDetailsTemp> retrieveSpecialistHospital(@PathVariable String specialist) {
		 return repository.emergencyType(specialist);
		
	}
	
}
