package com.microservices.gpshospitalservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


@Repository
public class HospitalRepository{
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public List<HospitalDetails> sendNotification(String HospitalId){
		
		
	     return jdbcTemplate.query("select * from hospital_details where hospital_id='"+HospitalId+"' ", new BeanPropertyRowMapper(HospitalDetails.class));
	     	
	}
	
	public List<HospitalDetailsTemp> emergency(){
		
	     List<HospitalDetails> data = jdbcTemplate.query("select * from hospital_details", new BeanPropertyRowMapper(HospitalDetails.class));
			

			jdbcTemplate.execute("create table temp ( hospital_id varchar(255), \n"
			 		+ "hospital_name varchar(255),\n"
			 		+ "	hospital_type varchar(255),\n"
			 		+ "        hospital_latitude float,\n"
			 		+ "	hospital_longitude float,\n"
			 		+ "        hospital_beds int,\n"
			 		+ "        hospital_doctors int,\n"
			 		+ "        hospital_nurses int,\n"
			 		+ "	final_distance float);");
	     
	     
	     data.forEach(d->{
	    	System.out.println(d.getHospitalId());
	    	 
	    	 double dis = DistanceCalculator.distance(d.getHospitalLatitude(),39.781482,d.getHospitalLongitude(),-84.071068);
	     String hospitalId = d.getHospitalId().toString(); 
	    	
	    	jdbcTemplate.update("insert into temp(hospital_id,hospital_name, "
			 		+ "hospital_type, hospital_latitude, hospital_longitude, hospital_beds,"
			 		+ "hospital_doctors,hospital_nurses, final_distance)"
			 		+ "values('"+d.getHospitalId()+"','"+d.getHospitalName()+"','"+d.getHospitalType()+"', 33.77061428824264, -104.06216362055677,'"+d.getHospitalBeds()+"','"+d.getHospitalDoctors()+"','"+d.getHospitalNurses()+"',"
			 		+ dis+");");
	    
	     }
	   );
	    
	     List<HospitalDetailsTemp> order = jdbcTemplate.query("SELECT * FROM TEMP where final_distance<10 order by final_distance limit 5", new BeanPropertyRowMapper(HospitalDetailsTemp.class));	
	    
	     order.forEach(o->{
	    	 System.out.println(o);
	     });
	     
	     jdbcTemplate.execute("drop table temp;");
	     
	     return order;
	    

		
		
	}
		 
	  
	public List<HospitalDetailsTemp> emergencyBeds(){
		
	     List<HospitalDetails> bedsData = jdbcTemplate.query("select * from hospital_details", new BeanPropertyRowMapper(HospitalDetails.class));
			

			jdbcTemplate.execute("create table temp ( hospital_id varchar(255), \n"
			 		+ "hospital_name varchar(255),\n"
			 		+ "	hospital_type varchar(255),\n"
			 		+ "        hospital_latitude float,\n"
			 		+ "	hospital_longitude float,\n"
			 		+ "        hospital_beds int,\n"
			 		+ "        hospital_doctors int,\n"
			 		+ "        hospital_nurses int,\n"
			 		+ "	final_distance float);");
	     
	     
	     bedsData.forEach(d->{
	    	double dis = DistanceCalculator.distance(d.getHospitalLatitude(),39.781482,d.getHospitalLongitude(),-84.071068);
	     
	    	jdbcTemplate.update("insert into temp(hospital_id,hospital_name, "
			 		+ "hospital_type, hospital_latitude, hospital_longitude, hospital_beds,"
			 		+ "hospital_doctors,hospital_nurses, final_distance)"
			 		+ "values('"+d.getHospitalId()+"','"+d.getHospitalName()+"','"+d.getHospitalType()+"', 33.77061428824264, -104.06216362055677,'"+d.getHospitalBeds()+"','"+d.getHospitalDoctors()+"','"+d.getHospitalNurses()+"',"
			 		+ dis+");");
	    
	     }
	   );
	    
	     List<HospitalDetailsTemp> bedsOrder = jdbcTemplate.query("SELECT * FROM TEMP where Hospital_Beds>0 and Hospital_type='covid' order by final_distance limit 5;", new BeanPropertyRowMapper(HospitalDetailsTemp.class));	
	     
	    		 bedsOrder.forEach(o->{
	    	 System.out.println(o);
	     });
	     
	     jdbcTemplate.execute("drop table temp;");

	     return bedsOrder;
		
	}
		 

	public List<HospitalDetailsTemp> emergencyType(String Hospital_Type){
		
	     List<HospitalDetails> typeData = jdbcTemplate.query("select * from hospital_details", new BeanPropertyRowMapper(HospitalDetails.class));
		
			jdbcTemplate.execute("create table temp ( hospital_id varchar(255), \n"
			 		+ "hospital_name varchar(255),\n"
			 		+ "	hospital_type varchar(255),\n"
			 		+ "        hospital_latitude float,\n"
			 		+ "	hospital_longitude float,\n"
			 		+ "        hospital_beds int,\n"
			 		+ "        hospital_doctors int,\n"
			 		+ "        hospital_nurses int,\n"
			 		+ "	final_distance float);");
	     
	     
	     typeData.forEach(d->{
	    	double dis = DistanceCalculator.distance(d.getHospitalLatitude(),39.781482,d.getHospitalLongitude(),-84.071068);
	     
	    	System.out.println(d.getHospitalName());
	    	jdbcTemplate.update("insert into temp(hospital_id,hospital_name, "
			 		+ "hospital_type, hospital_latitude, hospital_longitude, hospital_beds,"
			 		+ "hospital_doctors,hospital_nurses, final_distance)"
			 		+ "values('"+d.getHospitalId()+"','"+d.getHospitalName()+"','"+d.getHospitalType()+"', 33.77061428824264, -104.06216362055677,'"+d.getHospitalBeds()+"','"+d.getHospitalDoctors()+"','"+d.getHospitalNurses()+"',"
			 		+ dis+");");
	    
	     }
	   );
	    
	     List<HospitalDetailsTemp> TypeOrder = jdbcTemplate.query("SELECT * FROM TEMP where hospital_type='"+Hospital_Type+"' order by final_distance limit 5", new BeanPropertyRowMapper(HospitalDetailsTemp.class));	
	     
	    		 TypeOrder.forEach(o->{
	    	 System.out.println(o);
	     });
	     
	     jdbcTemplate.execute("drop table temp;");

	     return TypeOrder;
		
	}

	
}
	

