package com.microservices.gpshospitalservice;

public class HospitalSuggestion {
	
	
	private int sno;
	private String hospitalId;
	private String hospitalName;
	private Float distance;
	//route

}
