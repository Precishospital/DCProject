package com.microservices.gpshospitalservice;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;


public class HospitalDetails {

	
//	private int sNo;
	
	
	
	private String hospitalId;
	private String hospitalName;
	private String hospitalType;
	private float hospitalLatitude;
	private float hospitalLongitude;
	private int hospitalBeds;
	
	
	public HospitalDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public HospitalDetails(String hospitalId, String hospitalName, String hospitalType, float hospitalLatitude,
			float hospitalLongitude, int hospitalBeds, int hospitalDoctors, int hospitalNurses) {
		super();
		this.hospitalId = hospitalId;
		this.hospitalName = hospitalName;
		this.hospitalType = hospitalType;
		this.hospitalLatitude = hospitalLatitude;
		this.hospitalLongitude = hospitalLongitude;
		this.hospitalBeds = hospitalBeds;
		this.hospitalDoctors = hospitalDoctors;
		this.hospitalNurses = hospitalNurses;
	}
	@Override
	public String toString() {
		return "HospitalDetails [hospitalId=" + hospitalId + ", hospitalName=" + hospitalName + ", hospitalType="
				+ hospitalType + ", hospitalLatitude=" + hospitalLatitude + ", hospitalLongitude=" + hospitalLongitude
				+ ", hospitalBeds=" + hospitalBeds + ", hospitalDoctors=" + hospitalDoctors + ", hospitalNurses="
				+ hospitalNurses + "]";
	}
	public String getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getHospitalType() {
		return hospitalType;
	}
	public void setHospitalType(String hospitalType) {
		this.hospitalType = hospitalType;
	}
	public float getHospitalLatitude() {
		return hospitalLatitude;
	}
	public void setHospitalLatitude(float hospitalLatitude) {
		this.hospitalLatitude = hospitalLatitude;
	}
	public float getHospitalLongitude() {
		return hospitalLongitude;
	}
	public void setHospitalLongitude(float hospitalLongitude) {
		this.hospitalLongitude = hospitalLongitude;
	}
	public int getHospitalBeds() {
		return hospitalBeds;
	}
	public void setHospitalBeds(int hospitalBeds) {
		this.hospitalBeds = hospitalBeds;
	}
	public int getHospitalDoctors() {
		return hospitalDoctors;
	}
	public void setHospitalDoctors(int hospitalDoctors) {
		this.hospitalDoctors = hospitalDoctors;
	}
	public int getHospitalNurses() {
		return hospitalNurses;
	}
	public void setHospitalNurses(int hospitalNurses) {
		this.hospitalNurses = hospitalNurses;
	}
	private int hospitalDoctors;
	private int hospitalNurses;
	
	
		
			
	
}
