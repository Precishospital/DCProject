package com.microservices.gpshospitalservice;

import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;

import org.apache.http.NameValuePair;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.message.BasicNameValuePair;

import javax.activation.*;

public class EmailSender {

   public static void main(String [] args) {    
//      String to = "srinu9550182839@gmail.com";
//      String from = "ydg.preetham@gmail.com";
//      String host = "localhost";
//      Properties properties = System.getProperties();
//      properties.setProperty("mail.smtp.host", host);
//      Session session = Session.getDefaultInstance(properties);
//
//      try {
//         MimeMessage message = new MimeMessage(session);
//
//         message.setFrom(new InternetAddress(from));
//
//         message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
//
//         message.setSubject("stats");
//         message.setText("dsdfd");
//
//         Transport.send(message);
//         System.out.println("Sent message successfully....");
//      } catch (MessagingException mex) {
//         mex.printStackTrace();
//      }
	   
	   double lat1 = 40.74560;
	   double lon1 = -73.94622000000001;
	   double lat2 = 46.59122000000001;
	   double lon2 = -112.004230;

	   String url = "http://maps.googleapis.com/maps/api/directions/json?";

	   List<NameValuePair> params = new LinkedList<NameValuePair>();
	   params.add(new BasicNameValuePair("origin", lat1 + "," + lon1));
	   params.add(new BasicNameValuePair("destination", lat2 + "," + lon2));
	   params.add(new BasicNameValuePair("sensor", "false"));

	   String paramString = URLEncodedUtils.format(params, "utf-8");
	   url += paramString;
	   HttpGet get = new HttpGet(url);
	   System.out.println(get);
	   
   }
}
