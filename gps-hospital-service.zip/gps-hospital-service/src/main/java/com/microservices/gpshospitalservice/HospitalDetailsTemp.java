package com.microservices.gpshospitalservice;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;


public class HospitalDetailsTemp {

	
//	private int sNo;
//	
//	
	
	private String hospitalId;
	
	private String hospitalName;
	private String hospitalType;
	private float hospitalLatitude;
	private float hospitalLongitude;
	private int hospitalBeds;
	private int hospitalDoctors;
	private int hospitalNurses;
	private float final_distance;
	
	@Override
	public String toString() {
		return "HospitalDetailsTemp [hospitalId=" + hospitalId + ", hospitalName=" + hospitalName + ", hospitalType="
				+ hospitalType + ", hospitalLatitude=" + hospitalLatitude + ", hospitalLongitude=" + hospitalLongitude
				+ ", hospitalBeds=" + hospitalBeds + ", hospitalDoctors=" + hospitalDoctors + ", hospitalNurses="
				+ hospitalNurses + ", final_distance=" + final_distance + "]";
	}
	public HospitalDetailsTemp() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getHospitalId() {
		return hospitalId;
	}
	public void setHospitalId(String hospitalId) {
		this.hospitalId = hospitalId;
	}
	public String getHospitalName() {
		return hospitalName;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}
	public String getHospitalType() {
		return hospitalType;
	}
	public void setHospitalType(String hospitalType) {
		this.hospitalType = hospitalType;
	}
	public float getHospitalLatitude() {
		return hospitalLatitude;
	}
	public void setHospitalLatitude(float hospitalLatitude) {
		this.hospitalLatitude = hospitalLatitude;
	}
	public float getHospitalLongitude() {
		return hospitalLongitude;
	}
	public void setHospitalLongitude(float hospitalLongitude) {
		this.hospitalLongitude = hospitalLongitude;
	}
	public int getHospitalBeds() {
		return hospitalBeds;
	}
	public void setHospitalBeds(int hospitalBeds) {
		this.hospitalBeds = hospitalBeds;
	}
	public int getHospitalDoctors() {
		return hospitalDoctors;
	}
	public void setHospitalDoctors(int hospitalDoctors) {
		this.hospitalDoctors = hospitalDoctors;
	}
	public int getHospitalNurses() {
		return hospitalNurses;
	}
	public void setHospitalNurses(int hospitalNurses) {
		this.hospitalNurses = hospitalNurses;
	}
	public float getFinal_distance() {
		return final_distance;
	}
	public void setFinal_distance(float final_distance) {
		this.final_distance = final_distance;
	}
	public HospitalDetailsTemp(String hospitalId, String hospitalName, String hospitalType, float hospitalLatitude,
			float hospitalLongitude, int hospitalBeds, int hospitalDoctors, int hospitalNurses, float final_distance) {
		super();
		this.hospitalId = hospitalId;
		this.hospitalName = hospitalName;
		this.hospitalType = hospitalType;
		this.hospitalLatitude = hospitalLatitude;
		this.hospitalLongitude = hospitalLongitude;
		this.hospitalBeds = hospitalBeds;
		this.hospitalDoctors = hospitalDoctors;
		this.hospitalNurses = hospitalNurses;
		this.final_distance = final_distance;
	}
	
	
				
	
}
