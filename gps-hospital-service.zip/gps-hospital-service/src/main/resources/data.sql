create table hospital_details ( hospital_id varchar(255), 
hospital_name varchar(255),
	hospital_type varchar(255),
        hospital_latitude float,
	hospital_longitude float,
        hospital_beds int,
        hospital_doctors int,
	hospital_nurses int);



insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5001','Mayo Clinic', 'cardiac', 39.203392, -84.670070, 150,20,45);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5002','Cleveland Clinic', 'cardiac', 39.870768, -83.949907, 15,21,44);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5003','Massachusetts General Hospital', 'cardiac', 39.845424, -83.990727, 15,30,50);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5004','The Johns Hopkins Hospital', 'cardiac', 39.69124, -84.030007, 15,50,100);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5005','University of Michigan Hospitals - Michigan Medicine', 'cardiac', 39.729212, -84.199473, 15,16,40);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5006','UCSF Medical Center', 'cardiac', 39.619055, -84.096101, 15,15,50);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5007','Stanford Health Care Stanford Hospital', 'cardiac', 39.634211, -84.220078, 15,18,48);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5008','New York Presbyterian Hospital-Columbia and Cornell', 'general', 39.144946, -84.508543, 15,17,30);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5009','Hospital of the University of Pennsylvania Penn Presbyterian', 'general', 39.551683, -83.787781, 15,20,50);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5010','Ronald Reagan UCLA Medical Center', 'general', 39.74185, -84.401656, 15,21,44);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5011','University of Colorado Hospital', 'general', 39.825698, -84.200677, 15,16,75);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5012','Cedars-Sinai Medical Center', 'general', 39.887276, -84.046927, 15,30,90);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5013','The Mount Sinai Hospital', 'general', 39.711073, -84.202044, 15,23,70);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5014','Mayo Clinic Phoenix', 'general', 39.814481, -84.093989, 15,20,60);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5015','Duke University Hospital', 'general', 39.758138, -84.075183, 15,25,90);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5016','NYU Langone Hospitals', 'covid', 39.081157, -84.538703, 15,21,44);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5017','Northwestern Memorial Hospital', 'covid', 39.761692, -84.051235, 0,30,45);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5018','University of Wisconsin Hospitals', 'covid', 39.835612, -84.121139, 0,21,87);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5019','UCLA Medical Center', 'covid', 39.642304, -84.290535, 15,21,44);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5020','University of Washington Medical Center', 'covid', 39.821639, -84.28044, 15,32,50);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5021','Emory University Hospital', 'covid', 39.929154, -83.812529, 15,19,49);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5022','University Hospitals Cleveland Medical Center', 'covid', 39.693666, -83.962123, 15,30,85);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5023','Houston Methodist Hospital', 'covid', 39.635571, -84.081614, 15,50,115);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5024','Vanderbilt University Medical Center', 'pediatrics', 39.725837, -84.053741, 15,33,49);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5025','Scripps Memorial Hospital La Jolla', 'pediatrics', 39.685463, -84.1322, 15,41,90);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5026','OHSU Hospital', 'pediatrics', 39.6892191, -84.218649, 15,29,60);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5027','University of Kansas Hospital', 'pediatrics', 39.711386, -84.028943, 15,25,75);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5028','Keck Hospital of USC', 'pediatrics', 39.845424, -83.990727, 15,22,70);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5029','UPMC Presbyterian Shadyside', 'pediatrics', 39.819909, -84.201878, 15,20,56);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5030','Cleveland Clinic Fairview Hospital', 'pediatrics', 39.716732, -83.880535, 15,21,44);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5031','UT Southwestern Medical Center', 'pediatrics', 39.931534, -82.976937, 15,34,80);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5032','Yale New Haven Hospital', 'neuro', 39.886405, -82.944849, 15,10,18);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5033','Morristown Medical Center', 'neuro', 39.815891, -83.945734, 15,15,45);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5034','Beth Israel Deaconess Medical Center', 'neuro', 39.871676, -84.168393, 15,17,44);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5035','University of Chicago Medical Center', 'neuro', 39.835707, -83.914504, 15,30,77);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5036','Advocate Good Samaritan Hospital', 'neuro', 39.741382, -84.044245, 15,29,50);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5037','University of North Carolina Hospitals', 'neuro', 39.746438, -84.328446, 15,27,60);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5038','Torrance Memorial Medical Center', 'neuro', 39.843892, -84.421963, 15,20,65);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5039','Virginia Mason Medical Center', 'neuro', 39.777991, -84.053925, 15,27,50);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5040','UAB Hospital', 'neuro', 39.643088, -84.335439, 15,34,80);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h5041','Soin Medical Center - Kettering Health', 'neuro', 39.777991, -84.053925, 15,19,50);
insert into hospital_details(hospital_id,hospital_name, hospital_type, hospital_latitude, hospital_longitude, hospital_beds,hospital_doctors,hospital_nurses)
values('h50042','Brigham And Womens Hospital', 'cardiac', 39.812807, -84.227454, 15,10,40);
