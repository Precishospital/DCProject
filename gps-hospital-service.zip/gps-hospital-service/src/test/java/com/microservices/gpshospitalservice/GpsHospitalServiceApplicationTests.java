package com.microservices.gpshospitalservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpsHospitalServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
