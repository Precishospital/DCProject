import { createApp } from 'vue'
import App from './App.vue'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'

var app = createApp(App)
window.app = app
app.use(ElementPlus)
app.mount('#app')
