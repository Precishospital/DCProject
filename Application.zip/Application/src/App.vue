<script>
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup
import HelloWorld from './components/HelloWorld.vue'
import axios from 'axios'

export default {
  name: 'HelloWorld',
  data () {
    return {
      emergency: false,
      beds: false,
      reason: '',
      updateHospitalDetails: false,
      hospitalName: "",
      serachResults: false,
      dialogNotification: false,
      hospitalId: null,
      tableData: [],
      searchpi: '',
      ll:""
    }
  },
  methods: {

    async search () {

      // const resp = axios.get(`http://localhost:8080/${this.emergency ? 'emergency': 'beds'}`, )
      const resp = await axios.get(this.searchpi)
      console.log(resp)
      this.tableData = resp.data
      console.log(this.tableData)
      this.serachResults = true
    },
    changeStatus (type, status) {
      if (type === "emergency") {
        this.beds = false
        this.searchpi = "http://localhost:8080/emergency"
        
      }
      if (type === "beds") {
        this.emergency = false
        this.searchpi = "http://localhost:8080/beds"
      }
      this.reason=""
    },
    effected(){
      if(this.reason.length>0){
      this.searchpi=`http://localhost:8080/emergency/${this.reason}`
      this.beds=false
      this.emergency=false
      }
    },
    async update(){
      const resp = await axios.update("",{
        "hospitalName": this.hospitalName
      })
    },
    map(){
       this.ll="https://www.google.com/maps/dir/2315+Duncan+Dr,+Fairborn,+OH+45324/Soin+Medical+Center+-+Kettering+Health"
    }
  }

}

</script>

<template>
  

  <img style="width:20%" src="src/ph.jpeg"/>
  <el-dialog v-model="dialogNotification" title="Notification">
    <template #default>
     <el-input
          v-model="hospitalId"
          type="textarea"
          placeholder="Hospital ID"
          class="reason"
        />
    </template>
    <template #footer>
      <div class="dialog-footer">
        <el-button @click="dialogNotification = false">Cancel</el-button>
        <el-button type="primary">Submit</el-button
        >
      </div>
    </template>
  </el-dialog>

  <el-row>
    <el-col :span="14" class="box-dimensions">
      <el-card class="box-card">
      <template #header>
        <div class="card-header">
            <span>Hospital search</span>
          </div>
        </template>
        <el-row>
        <el-checkbox v-model="emergency" label="Emergency" @click="changeStatus('emergency')"></el-checkbox>
        <el-checkbox v-model="beds" label="Beds" @click="changeStatus('beds')"></el-checkbox>
        <el-input
          v-model="reason"
          type="textarea"
          @keyup="effected()"
          placeholder="Effected Area"
          class="reason"
        />
        </el-row>
        <el-row>
          <el-button type="success" @click="search()">Search</el-button>
        </el-row>
      </el-card>
    </el-col>
     <el-col :span="10" class="box-dimensions">
      <el-card class="box-card">
      <template #header>
        <div class="card-header">
            <span>Government hospital notification</span>
          </div>
        </template>
        <el-row style="float: right;">
      <el-button  type="info" size="mini" @click="dialogNotification=true">Send notification</el-button>
      </el-row>
      <el-row>
        <el-col><h4 style="display: inline; margin: 0px !important;">Hospital Details</h4>
        </el-col>
      </el-row>
      <el-row style="padding-top: 25px;">
        <el-col :span="12" class="display-inline">
          <b style="padding-right: 15px;">Hospital_Id</b>
          <el-input v-model="hospitalName" class="update-input"></el-input>
        </el-col>
         <el-col :span="12" class="display-inline">
            <b style="padding-right: 15px;">Doctors</b>
            <el-input v-model="hospitalName" class="update-input"></el-input>
         </el-col>
         <el-col :span="12" class="display-inline" style="padding-top: 10px">
          <b style="padding-right: 15px;">Beds</b>
          <el-input v-model="hospitalName" class="update-input"></el-input>
        </el-col>
         <!-- <el-col :span="12" class="display-inline" style="padding-top: 10px">
            <b style="padding-right: 15px;">Name</b>
            <el-input v-model="hospitalName" class="update-input"></el-input>
         </el-col>
         <el-col :span="12" class="display-inline" style="padding-top: 10px">
          <b style="padding-right: 15px;">Name</b>
         <el-input v-model="hospitalName" class="update-input"></el-input>
        </el-col>
         <el-col :span="12" class="display-inline" style="padding-top: 10px">
            <b style="padding-right: 15px;">Name</b>
            <el-input v-model="hospitalName" class="update-input"></el-input>
         </el-col> --> 
      </el-row>
       <el-row style="padding-top: 10px;">
         <el-button  type="success" size="mini" @click="update()">Update</el-button>
       </el-row>
      </el-card>
    </el-col>
  </el-row>


  <el-row class="search-results" v-if="serachResults">
    <el-col :span="14">
     <el-card class="box-card">
      <template #header>
        <div class="card-header">
           <span>Search results</span>
          </div>
          </template>
        <el-table :data="tableData" style="width: 100%">
          <el-table-column prop="hospitalId" label="Hospital_Id" width="180" />
          <el-table-column prop="hospitalName" label="Hospital_Name" width="180" />
          <el-table-column prop="final_distance" label="Distance" />
          <el-table-column label="Notification">
            <template #default="scope">
              <el-button size="mini" @click="handleEdit(scope.$index, scope.row)"
                >Notification</el-button
              >


            </template>
          </el-table-column>
          <el-table-column label="RouteMap">
            <template #default="scope">
              <a :href="ll" 
                
                @click=map() target="_blank">{{scope.row.hospitalId}}</a >
              
            </template>
          </el-table-column>
        </el-table>
     </el-card>
    </el-col>
  </el-row>
  <!-- <HelloWorld msg="Hello Vue 3 + Vite" /> -->
</template>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
.box-dimensions {
  padding-right: 25px;
  text-align: left;
  display: block;
}
.reason {
  width: 60% !important;
  padding-left: 25px;margin-top: 10px;
}
.search-results {
  padding-top: 25px;
  text-align: left;
  position: absolute !important;
  width: 95%;
  top: 22em;
}
.display-inline {
  display: inline;
}
.update-input {
  width: 80% !important;
  padding-top: 10px;
}
</style>
